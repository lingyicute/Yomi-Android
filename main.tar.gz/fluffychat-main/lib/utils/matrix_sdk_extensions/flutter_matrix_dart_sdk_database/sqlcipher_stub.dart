Future<void> applyWorkaroundToOpenSqlCipherOnOldAndroidVersions() async {}
